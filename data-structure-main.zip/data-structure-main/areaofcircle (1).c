#include<stdio.h>
int main(){
    float radius,pi;
    pi=3.14;
    printf("radius of circle = ");
    scanf("%f",&radius);
    printf("area of circle is= %f",pi*radius*radius);
    return 0;
}