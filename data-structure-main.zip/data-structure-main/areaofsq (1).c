#include<stdio.h>
int main(){
    int side;
    printf("side of sq = ");
    scanf("%d",&side);
    printf("are of sq = %d",side*side);
    return 0;
}